"""
AWS S3 백업 설정. 값은 여기서 직접 관리한다 (프로그램 내 입력 UI 없음).
"""

AWS_ACCESS_KEY_ID = "AKIARFGBGTO6XJV47HXD"
AWS_SECRET_ACCESS_KEY = "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"

AWS_REGION = "ap-northeast-2"  # 서울
AWS_BUCKET = "jmo-lms"

AWS_DB_PREFIX = "JMO_LMS_DB"    # DB 백업 저장 폴더
AWS_EXE_PREFIX = "JMO_LMS_EXE"  # 프로그램 업데이트(exe) 폴더
